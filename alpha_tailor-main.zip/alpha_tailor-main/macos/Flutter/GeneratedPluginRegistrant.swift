//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import device_info_plus

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  DeviceInfoPlusMacosPlugin.register(with: registry.registrar(forPlugin: "DeviceInfoPlusMacosPlugin"))
}
