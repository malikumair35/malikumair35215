import 'package:flutter/material.dart';

class SuitTrackingScreen extends StatelessWidget {
  final List<Map<String, String>> trackingSteps = [
    {"title": "Order Placed", "date": "2025-01-01", "status": "Completed"},
    {"title": "Measurements Received", "date": "2025-01-02", "status": "Completed"},
    {"title": "Design Under Progress", "date": "2025-01-05", "status": "In Progress"},
    {"title": "Quality Check", "date": "-", "status": "Pending"},
    {"title": "Out for Delivery", "date": "-", "status": "Pending"},
    {"title": "Delivered", "date": "-", "status": "Pending"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Suit Tracking"),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView.builder(
        itemCount: trackingSteps.length,
        itemBuilder: (context, index) {
          final step = trackingSteps[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: step["status"] == "Completed"
                    ? Colors.green
                    : step["status"] == "In Progress"
                    ? Colors.orange
                    : Colors.grey,
                child: Icon(
                  step["status"] == "Completed"
                      ? Icons.check
                      : step["status"] == "In Progress"
                      ? Icons.refresh
                      : Icons.hourglass_empty,
                  color: Colors.white,
                ),
              ),
              title: Text(step["title"]!),
              subtitle: Text("Date: ${step["date"]}"),
              trailing: Text(
                step["status"]!,
                style: TextStyle(
                  color: step["status"] == "Completed"
                      ? Colors.green
                      : step["status"] == "In Progress"
                      ? Colors.orange
                      : Colors.grey,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
