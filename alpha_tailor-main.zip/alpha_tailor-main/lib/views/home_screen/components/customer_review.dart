import 'package:flutter/material.dart';


class CustomerReviewPage extends StatefulWidget {
  const CustomerReviewPage({super.key});

  @override
  State<CustomerReviewPage> createState() => _CustomerReviewPageState();
}

class _CustomerReviewPageState extends State<CustomerReviewPage> {




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Best Customer Reviews in appBar'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Text('Ask for tailor recommendation', style: TextStyle(fontSize: 18, color: Colors.black),),
            Align(
                alignment: Alignment.topLeft,
                child: Text('Drop Down')),
            TextField(
              decoration: InputDecoration(
                  isDense: true,
                  hintText: 'Select the tailor',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  )
              ),
            ),
            SizedBox(height: 20,),
            TextField(
              decoration: InputDecoration(
                  isDense: true,
                  hintText: 'who recommend',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  )
              ),
            ),
            SizedBox(height: 20,),
            Center(
              child: Container(
                height: 40, width: 220,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue, width: 2),
                  color: Colors.deepPurple
                ),
                child: Center(
                  child: Text('Hire Me', style: TextStyle(fontSize: 18, color: Colors.white),),
                ),
              ),
            ),
            SizedBox(height: 20,),
            Text('Top Tailors', style: TextStyle(fontSize: 18, color: Colors.black),),
            SizedBox(height: 20,),
            Flexible(
              child: ListView.builder(
                  itemCount: 3,
                  itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListTile(
                    tileColor: Colors.blueGrey.shade100,
                    leading: Icon(Icons.highlight_remove, color: Colors.black,),
                    title: Text('Ahmed Munir', style: TextStyle(fontSize: 18, color: Colors.black),),
                    subtitle: Text('Karim khan: Your give us great service', style: TextStyle(fontSize: 12, color: Colors.grey),),
                    trailing: Icon(Icons.keyboard_arrow_left, color: Colors.black,),
                  ),
                );
              }),
            )

          ],
        ),
      )
    );
  }
}
