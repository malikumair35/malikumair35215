import 'package:flutter/material.dart';

import '../../tailor_detail/tailor_detail.dart';
import 'detail_page/detail_page.dart';
import 'package:flutter/material.dart';
import 'detail_page/detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = -1;

  List<String> namesList = [
    'Ahmed Tanoli',
    'Faraz Naeem',
    'Ahmed Karim',
    'Fkhar sddff',
    'munj kinj',
    'kuna nij',
  ];

  final List<String> address = [
        'Chaklala Rawalpindi, Pakistan',
        'Saddar Rawalpindi, Pakistan',
        'i8 Islamabad, Pakistan',
        'i10/3 Islamabad, Pakistan',
        'F12 Islamabad, Pakistan',
        'G10 Islamabad, Pakistan',
  ];


  List<NetworkImage> suitsList = [
    NetworkImage('https://i.pinimg.com/736x/de/fe/a9/defea96d40ce2fd53a86763aafbc9e42.jpg'),
    NetworkImage('https://www.justsuitsformen.com/resources/burgundy%20suit%20male%20model%202.jpg.opt409x409o0%2C0s409x409.jpg'),
    NetworkImage('https://i.etsystatic.com/45167899/r/il/f70390/5917069142/il_570xN.5917069142_qlu8.jpg'),
    NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHp3NbwA6vf0X5DbOHZCvq6UrdA4mIu_yAhQ&s'),
    NetworkImage('https://i.pinimg.com/736x/de/fe/a9/defea96d40ce2fd53a86763aafbc9e42.jpg'),
    NetworkImage('https://www.justsuitsformen.com/resources/burgundy%20suit%20male%20model%202.jpg.opt409x409o0%2C0s409x409.jpg'),
    NetworkImage('https://i.etsystatic.com/45167899/r/il/f70390/5917069142/il_570xN.5917069142_qlu8.jpg'),
    NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHp3NbwA6vf0X5DbOHZCvq6UrdA4mIu_yAhQ&s'),
    NetworkImage('https://i.pinimg.com/736x/de/fe/a9/defea96d40ce2fd53a86763aafbc9e42.jpg'),
    NetworkImage('https://www.justsuitsformen.com/resources/burgundy%20suit%20male%20model%202.jpg.opt409x409o0%2C0s409x409.jpg'),
    NetworkImage('https://i.etsystatic.com/45167899/r/il/f70390/5917069142/il_570xN.5917069142_qlu8.jpg'),
    NetworkImage('https://i.etsystatic.com/45167899/r/il/f70390/5917069142/il_570xN.5917069142_qlu8.jpg'),
    NetworkImage('https://i.etsystatic.com/45167899/r/il/f70390/5917069142/il_570xN.5917069142_qlu8.jpg'),
    NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHp3NbwA6vf0X5DbOHZCvq6UrdA4mIu_yAhQ&s'),
  ];
  List<NetworkImage> darziList = [
    NetworkImage('https://content.jdmagicbox.com/comp/dharmavaram/x5/9999p8559.8559.180208190214.a5x5/catalogue/kumar-tailors-dharmavaram-tailors-1vxv7iqzej.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/proddatur/g9/9999p8564.8564.180517194043.x3g9/catalogue/sr-tilors-proddatur-w3ipg-250.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/puri/e8/9999p6752.6752.231114134017.a8e8/catalogue/maa-dakhinakali-ladies-and-gents-tailor-puri-tailors-jpkrujy7zt.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/jangareddygudem/p1/9999p8821.8821.181227101528.m4p1/catalogue/nicely-tilors-jangareddygudem-0dnebjrpnw-250.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/proddatur/g9/9999p8564.8564.180517194043.x3g9/catalogue/sr-tilors-proddatur-w3ipg-250.jpg'),
    NetworkImage('https://www.justsuitsformen.com/resources/burgundy%20suit%20male%20model%202.jpg.opt409x409o0%2C0s409x409.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/puri/e8/9999p6752.6752.231114134017.a8e8/catalogue/maa-dakhinakali-ladies-and-gents-tailor-puri-tailors-jpkrujy7zt.jpg'),
    NetworkImage('https://content.jdmagicbox.com/comp/proddatur/g9/9999p8564.8564.180517194043.x3g9/catalogue/sr-tilors-proddatur-w3ipg-250.jpg'),
  ];

  // final Map<String, List<String>> detailsMap = {
  //   'https://i.pinimg.com/736x/de/fe/a9/defea96d40ce2fd53a86763aafbc9e42.jpg': [
  //     'https://i.pinimg.com/736x/de/fe/a9/defea96d40ce2fd53a86763aafbc9e42.jpg',
  //     'https://i.pinimg.com/originals/6e/1e/84/6e1e84ad246c908ff35d24891ccdd544.jpg',
  //     'https://i.pinimg.com/originals/c6/d0/78/c6d078d99b85dbf49d69f92bd50af860.jpg',
  //     'https://i.pinimg.com/originals/3a/1b/13/3a1b13c92d902c4d2a150db354325a55.jpg',
  //     'https://i.pinimg.com/originals/29/42/a3/2942a34a4a61294ae17f25e6c6d88538.jpg',
  //   ],
  //   // Add other entries for the remaining suits
  // };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Text('Don\'t find let\'s contact', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400, color: Colors.blueGrey)),
            SizedBox(height: 20),
            Flexible(
              child: GridView.builder(
                itemCount: 4,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  childAspectRatio: 9 / 6,
                ),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailPage(image: suitsList[index]),
                        ),
                      );
                    },
                    child: Container(
                      height: 200,
                      width: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blueGrey),
                        image: DecorationImage(image: suitsList[index], fit: BoxFit.fitWidth),
                      ),
                    ),
                  );
                },
              ),
            ),
            Text('Top Tailors'),
            Flexible(
              child: ListView.builder(
                itemCount: 6,
                itemBuilder: (context, index) {
                  bool isSelected = index == _selectedIndex;
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedIndex = isSelected ? -1 : index; // Toggle selection
                      });

                     Navigator.push(context, MaterialPageRoute(builder: (context) => TailorDetail()));

                      // Navigate to DetailPage with data
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) => DetailPage(image: darziList[index], details: detailsMap[suitsList[index].url]!),
                      //   ),
                      // );
                    },
                    child: Container(
                      padding: EdgeInsets.all(10),
                      margin: EdgeInsets.symmetric(vertical: 5),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.blueAccent : Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: isSelected ? [BoxShadow(color: Colors.blue, blurRadius: 10)] : [BoxShadow(color: Colors.black12, blurRadius: 5)],
                      ),
                      child: ListTile(
                        title: Text(namesList[index]),
                        subtitle: Text(
                          address[index],
                          overflow: TextOverflow.ellipsis,
                        ),
                        leading: CircleAvatar(backgroundImage: darziList[index]),
                        trailing: Icon(Icons.star_rate, color: isSelected ? Colors.white : Colors.black),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  final NetworkImage image;
  final List<String>? details;

  DetailPage({required this.image, this.details});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Suit Details')),
      body: Column(
        children: [
          Image(image: image),
          if (details != null)
            Expanded(
              child: ListView.builder(
                itemCount: details!.length,
                itemBuilder: (context, index) {
                  return Image.network(details![index]);
                },
              ),
            ),
        ],
      ),
    );
  }
}