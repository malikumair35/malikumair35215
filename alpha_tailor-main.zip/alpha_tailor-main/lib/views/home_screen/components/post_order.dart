import 'package:flutter/material.dart';


class PostOrderPage extends StatefulWidget {
  const PostOrderPage({super.key});

  @override
  State<PostOrderPage> createState() => _PostOrderPageState();
}

class _PostOrderPageState extends State<PostOrderPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 26),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 30,),
              Center(
                child: Container(
                  height: 180,
                  width: 300,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey, width: 2),
                    color: Colors.blueGrey.shade50
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    spacing: 40,
                    children: [
                      Text('upload image', style: TextStyle(color: Colors.black45),),
                      Icon(Icons.cloud_upload_outlined, size: 40,color: Colors.grey,)
                    ],
                  ),
                ),
              ),
              SizedBox(height: 30,),
              Align(
                  alignment: Alignment.topLeft,
                  child: Text('Description', style: TextStyle(fontSize: 16),)),
              TextField(
                decoration: InputDecoration(
                    isDense: true,
                    hintText: 'I want to stich my suit within 3 days but the budget is under 700',
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                    )
                ),
              ),
              SizedBox(height: 30,),
              Align(
                  alignment: Alignment.topLeft,
                  child: Text('Budget', style: TextStyle(fontSize: 16),)),
              TextField(
                decoration: InputDecoration(
                    isDense: true,
                    hintText: 'Select your budget',
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                    )
                ),
              ),
              SizedBox(height: 30,),
              Align(
                  alignment: Alignment.topLeft,
                  child: Text('Delivery days', style: TextStyle(fontSize: 16),)),
              TextField(
                decoration: InputDecoration(
                    isDense: true,
                    hintText: 'I want to stich my suit within 3 days but the budget is under 700',
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                    )
                ),
              ),
              SizedBox(height: 30,),
              Align(
                  alignment: Alignment.topLeft,
                  child: Text('Suits number', style: TextStyle(fontSize: 16),)),
              TextField(
                decoration: InputDecoration(
                    isDense: true,
                    hintText: 'I want to stich my suit within 3 days but the budget is under 700',
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                    )
                ),
              ),
              SizedBox(height: 30,),
              Center(
                child: Container(
                  height: 50, width: 320,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue, width: 2),
                      color: Colors.deepPurple
                  ),
                  child: Center(
                    child: Text('Post Me', style: TextStyle(fontSize: 18, color: Colors.white),),
                  ),
                ),
              ),
              SizedBox(height: 30,),
          
            ],
          ),
        ),
      ),
    );
  }
}
