import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  final NetworkImage image;

  const DetailPage({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    // Create a list of the same image for display
    List<NetworkImage> similarImages = List.generate(5, (index) => image);

    return Scaffold(
      appBar: AppBar(
        title: Text('Image Details'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Text(
              'Similar Images',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: GridView.builder(
                itemCount: similarImages.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  childAspectRatio: 9 / 6,
                ),
                itemBuilder: (context, index) {
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blueGrey),
                      image: DecorationImage(
                        image: similarImages[index],
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
