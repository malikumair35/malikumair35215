import 'package:flutter/material.dart';
import '../drawer_screen/drawer_screen.dart';
import 'components/home_page.dart';
import 'components/customer_review.dart';
import 'components/post_order.dart';
import 'components/track_suit.dart'; // Import your HomePage

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  // List of pages
  final List<Widget> _pages = [
    HomePage(), // HomePage widget
    CustomerReviewPage(),
    PostOrderPage(),
    SuitTrackingScreen(),
  ];


  // list of tailors address


  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alpha Tailor'),
        backgroundColor: Colors.teal,

      ),
      drawer: CustomDrawer(),
      body: _pages[_selectedIndex], // Display the selected page
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text("Tailor Experience"),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("OK"),
                )
              ],
            ),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.teal,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        notchMargin: 6.0,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                icon: Icon(Icons.home, color: _selectedIndex == 0 ? Colors.teal : Colors.grey),
                onPressed: () => _onItemTapped(0),
              ),
              IconButton(
                icon: Icon(Icons.contact_phone, color: _selectedIndex == 1 ? Colors.teal : Colors.grey),
                onPressed: () => _onItemTapped(1),
              ),
              SizedBox(width: 40), // Space for the FAB
              IconButton(
                icon: Icon(Icons.help, color: _selectedIndex == 2 ? Colors.teal : Colors.grey),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon: Icon(Icons.person, color: _selectedIndex == 3 ? Colors.teal : Colors.grey),
                onPressed: () => _onItemTapped(3),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
//
// class CustomDrawer extends StatelessWidget {
//   const CustomDrawer({
//     super.key,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//         child: ListView(
//         padding: EdgeInsets.zero,
//     children: [
//       DrawerHeader(
//         decoration: BoxDecoration(
//           color: Colors.blue,
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             CircleAvatar(
//               radius: 30,
//               backgroundImage: AssetImage('assets/profile_picture.png'), // Replace with your profile image path
//             ),
//             SizedBox(height: 10),
//             Text(
//               'Umair Zia',
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 18,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             Text(
//               'user@example.com',
//               style: TextStyle(
//                 color: Colors.white70,
//                 fontSize: 14,
//               ),
//             ),
//           ],
//         ),
//       ),
//       ListTile(
//         leading: Icon(Icons.person),
//         title: Text('Profile'),
//         onTap: () {
//           // Navigate to Profile Screen
//           Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
//         },
//       ),
//       ListTile(
//         leading: Icon(Icons.settings),
//         title: Text('Settings'),
//         onTap: () {
//           // Navigate to Settings Screen
//           Navigator.pushNamed(context, '/settings');
//         },
//       ),
//       ListTile(
//         leading: Icon(Icons.lock),
//         title: Text('Privacy Policy'),
//         onTap: () {
//           // Navigate to Privacy Policy Screen
//           Navigator.pushNamed(context, '/privacy');
//         },
//       ),
//       ListTile(
//         leading: Icon(Icons.star),
//         title: Text('Tailor Points'),
//         onTap: () {
//           // Navigate to Tailor Points Screen
//           Navigator.pushNamed(context, '/tailor_points');
//         },
//       ),
//       Divider(),
//
//       Padding(
//         padding: const EdgeInsets.all(25.0),
//         child: GestureDetector(
//           onTap: (){
//             Navigator.pop(context);
//           },
//           child: Container(
//             height: 40,
//             decoration: BoxDecoration(
//               color: Colors.deepPurple,
//               borderRadius: BorderRadius.circular(8),
//               border: Border.all(color: Colors.brown)
//             ),
//             child: Center(child: Text('Logout', style: TextStyle(color: Colors.white),)),
//           ),
//         ),
//       ),
//       ListTile(
//         leading: Icon(Icons.logout),
//         title: Text('Logout'),
//         onTap: () {
//           // Perform Logout
//           Navigator.pop(context);
//           // Implement your logout functionality
//         },
//       ),
//     ],
//         ),
//         );
//   }
// }












class CustomDrawer extends StatelessWidget {
  const CustomDrawer({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: AssetImage(
                      'assets/profile_picture.png'), // Replace with your profile image path
                ),
                SizedBox(height: 10),
                Text(
                  'Umair Zia',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'user@example.com',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Profile'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => ProfileScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Settings'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => SettingsScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.lock),
            title: Text('Privacy Policy'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => PrivacyPolicyScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text('Order/Booking'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => OrdersScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.track_changes),
            title: Text('Suit Tracking'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => SuitTrackingScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text('Notifications'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => NotificationsScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.help),
            title: Text('Help & Support'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => HelpSupportScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.star),
            title: Text('Tailor Points'),
            onTap: () {
              // Navigate to Profile Screen
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => TailorPointsScreen()));
            },
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.deepPurple,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.brown),
                ),
                child: Center(
                  child: Text(
                    'Logout',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text('Logout'),
            onTap: () {
              // Perform Logout
              Navigator.pop(context);
              // Implement your logout functionality
            },
          ),
        ],
      ),
    );
  }
}

