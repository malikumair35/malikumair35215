import 'package:alpha_tailor/utils/app_images.dart';
import 'package:alpha_tailor/views/resetPassword_sceens/update_password.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class OTPScreen extends StatefulWidget {
  const OTPScreen({super.key});

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  bool _isOTPComplete = false; // Tracks OTP completion
  String _currentOTP = ''; // Stores the current OTP value

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Reset Password',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                AppImages.resetPassword2,
                scale: 8,
              ),
              const Text(
                'Enter your phone number to reset your password.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w400,
                  color: Colors.blueGrey,
                ),
              ),
              const SizedBox(height: 20),
              PinCodeTextField(
                length: 6,
                obscureText: false,
                animationType: AnimationType.fade,
                pinTheme: PinTheme(
                  shape: PinCodeFieldShape.underline,
                  borderRadius: BorderRadius.circular(10),
                  fieldHeight: 60,
                  fieldWidth: 50,
                  activeFillColor: Colors.lightBlue.shade50,
                  inactiveFillColor: Colors.white,
                  selectedFillColor: Colors.lightBlue.shade100,
                  activeColor: Colors.blue,
                  inactiveColor: Colors.grey,
                  selectedColor: Colors.blueAccent,
                ),
                animationDuration: const Duration(milliseconds: 200),
                backgroundColor: Colors.transparent,
                enableActiveFill: true,
                keyboardType: TextInputType.number,
                textStyle: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                cursorColor: Colors.blue,
                onCompleted: (value) {
                  setState(() {
                    _isOTPComplete = true;
                    _currentOTP = value;
                  });
                },
                onChanged: (value) {
                  setState(() {
                    _isOTPComplete = value.length == 6;
                    _currentOTP = value;
                  });
                },
                beforeTextPaste: (text) {
                  return true;
                },
                autoFocus: true,
                autoDismissKeyboard: true,
                appContext: context,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isOTPComplete
                    ? () {
                  // Navigate to the next screen
                  Navigator.push(context, MaterialPageRoute(builder: (context) => UpdatePasswordScreen()));
                }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                  _isOTPComplete ? Colors.blue : Colors.grey, // Dynamic color
                  padding: const EdgeInsets.symmetric(
                      horizontal: 30, vertical: 15), // Button padding
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Rounded corners
                  ),
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
