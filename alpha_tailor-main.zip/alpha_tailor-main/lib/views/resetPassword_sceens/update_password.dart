import 'package:alpha_tailor/utils/app_images.dart';
import 'package:alpha_tailor/views/auth/login_screen/login_screen.dart';
import 'package:flutter/material.dart';

class UpdatePasswordScreen extends StatefulWidget {
  const UpdatePasswordScreen({super.key});

  @override
  State<UpdatePasswordScreen> createState() => _UpdatePasswordScreenState();
}

class _UpdatePasswordScreenState extends State<UpdatePasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 100,),
          Center(child: Image.asset(AppImages.updatePassword, scale: 8,)),
            SizedBox(height: 40,),
            Text('Successfully!', style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.w600,
              color: Colors.deepPurple
            ),),

            Text('Your Password has been changed!', style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.w600,
              color: Colors.blueGrey
            ),),
            SizedBox(height: 100,),
            SizedBox(
              width: 300,
              child: ElevatedButton(
                onPressed: () {
                  // Navigate to the next screen
                  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 30, vertical: 15), // Button padding
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Rounded corners
                  ),
                ),
                child: const Text(
                  'Back to Login',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )

          ],
        ),
      ),
    );
  }
}
