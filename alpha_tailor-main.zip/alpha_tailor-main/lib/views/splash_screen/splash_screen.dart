import 'dart:async';
import 'package:alpha_tailor/views/onBoarding_screens/onBoarding_view.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

import '../../utils/app_images.dart';
import '../auth/login_screen/login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _startLoading();
  }

  void _startLoading() {
    Timer.periodic(Duration(milliseconds: 50), (timer) {
      setState(() {
        _progress += 0.01; // Increment progress by 1%
        if (_progress >= 1.0) {
          _progress = 1.0; // Clamp to 1.0 to avoid exceeding
          timer.cancel(); // Stop the timer
          _navigateToLogin(); // Navigate to the login screen
        }
      });
    });
  }

  void _navigateToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => OnboardingView()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Tailors experience to get a suit before EID'),
          Center(
            child: Container(
              height: 300,
              width: 340,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(AppImages.tailorIcon),
                  fit: BoxFit.scaleDown,
                ),
              ),
            ),
          ),
          Center(
            child: CircularPercentIndicator(
              radius: 40.0,
              lineWidth: 8.0,
              percent: _progress,
              center: Text(
                "${(_progress * 100).toInt()}%",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
              progressColor: Colors.green,
            ),
          ),
        ],
      ),
    );
  }
}
