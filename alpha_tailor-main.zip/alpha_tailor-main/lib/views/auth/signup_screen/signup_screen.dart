import 'package:alpha_tailor/utils/app_images.dart';
import 'package:alpha_tailor/views/auth/login_screen/login_screen.dart';
import 'package:flutter/material.dart';

class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(
          height: double.infinity,width: double.infinity,
          decoration: const BoxDecoration(

          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: SingleChildScrollView(
              child: Column(
                spacing: 14,
                children: [
                  SizedBox(height: 30,),
                  Image.asset(AppImages.tailorIcon, scale: 4,),
                  RichText(
                      textAlign: TextAlign.center,
                      textScaler: TextScaler.linear(1.0),
                      textHeightBehavior: TextHeightBehavior(
                          applyHeightToFirstAscent: true,
                          applyHeightToLastDescent: true,
                          leadingDistribution: TextLeadingDistribution.proportional
                      ),
                      text: TextSpan(
                          text: 'For logging In securely\n', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.grey.shade200,
                          shadows: [
                            Shadow(
                              color: Colors.grey.withValues(alpha: 0.9),
                              offset: Offset(2.8, 3.6),
                              blurRadius: 3,
                            )]),
                          children: [
                            TextSpan(text: 'create new credentials', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.amber.shade200,
                                shadows: [
                                  Shadow(
                                    color: Colors.grey.withOpacity(0.9),
                                    offset: Offset(1.8, 2.6),
                                    blurRadius: .4,
                                  )]))
                          ]
                      )),
              
                  SizedBox(height: 20,),
                  Row(
                    spacing: 14,
                    children: [
                      Flexible(
                        child: TextFormField(
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: 'First Name',
                            prefixIcon: Icon(Icons.person),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            fillColor: Colors.amber.shade50,
                            filled: true,
                          ),
                        ),
                      ),
                      Flexible(
                        child: TextFormField(
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: 'Last Name',
                            prefixIcon: Icon(Icons.person),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            fillColor: Colors.amber.shade50,
                            filled: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Email',
                      prefixIcon: Icon(Icons.email),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      fillColor: Colors.amber.shade50,
                      filled: true,
                    ),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Phone',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      fillColor: Colors.amber.shade50,
                      filled: true,
                    ),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Password',
                      prefixIcon: Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      fillColor: Colors.amber.shade50,
                      filled: true,
                    ),
                  ),
                  TextFormField(
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Confirm Password',
                      prefixIcon: Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      fillColor: Colors.amber.shade50,
                      filled: true,
                    ),
                  ),
              
                  SizedBox(
                    height: 50,
                    width: double.infinity,
                    child: ElevatedButton(
                        style: ButtonStyle(backgroundColor: WidgetStatePropertyAll(Color(0XFF190152)),
                            shape: WidgetStatePropertyAll(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(color: Colors.blueGrey, width: 2),
                              ),
                            ),
                            surfaceTintColor: WidgetStatePropertyAll(Colors.black)
                        ),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
                        },
                        child: Text('Signup Yourself',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              color: Colors.grey.shade300,
                              shadows: [
                                Shadow(
                                    color: Colors.grey.shade700,
                                    offset: Offset(.4, 1.2),blurRadius: 3
                                )
                              ]
                          ),
                        )
                    ),
                  ),
                  Row(
                    children: [
                      Flexible(child: Divider(color: Colors.grey,)),
                      Text(
                        '   Or signup with   ',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Flexible(child: Divider(color: Colors.grey,)),
                    ],),
                  Center(child: Icon(Icons.facebook, color: Colors.blue, size: 40,)),
                  Row(
                    children: [
                      Text('Already have an account?? ' ,style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700,
                      ),),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
                        },
                        child: Text('Login Account ' ,
                          style: TextStyle(
                          fontSize: 19, fontWeight: FontWeight.w700,
                            color: Colors.blue
                        ),),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}