import 'package:alpha_tailor/utils/app_images.dart';
import 'package:alpha_tailor/views/home_screen/home_screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../resetPassword_sceens/reset_password.dart';
import '../signup_screen/signup_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isSelected = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(
          height: double.infinity, width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25),

            child: SingleChildScrollView(
              child: Column(
                spacing: 16,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 40),
                  Row(
                    children: [
                      Text(
                          'Logging Account',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w400, color: Colors.black)),
                      SizedBox(width: 15),
                      Icon(Icons.person)
                    ],
                  ),
                  Text(
                      'Hello, welcome back to our account!',
                      style: TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w400, color: Colors.black)),
                  SizedBox(height: 20),
                  Center(child: Image.asset(AppImages.sewMachine, scale: 1.7)),
              
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _isSelected = true;
                          });
                        },
                        child: Container(
                          height: 40,
                          width: 130,
                          decoration: BoxDecoration(
                              color: _isSelected ? Colors.green : Colors.grey,
                              border: Border.all(color: Colors.blueGrey),
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(6), topLeft: Radius.circular(6))),
                          child: Center(
                            child: Text(
                              'Email Login',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _isSelected = false;
                          });
                        },
                        child: Container(
                          height: 40,
                          width: 130,
                          decoration: BoxDecoration(
                              color: !_isSelected ? Colors.green : Colors.grey,
                              border: Border.all(color: Colors.blueGrey),
                              borderRadius: BorderRadius.only(
                                  bottomRight: Radius.circular(6), topRight: Radius.circular(6))),
                          child: Center(
                            child: Text(
                              'Phone Number',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
              
                  if (_isSelected) ...[
                    // Email Login Fields
                    TextFormField(
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Email',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        fillColor: Colors.amber.shade50,
                        filled: true,
                        prefixIcon: Icon(
                          Icons.mail,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                    TextFormField(
                      obscureText: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Password',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        fillColor: Colors.amber.shade50,
                        filled: true,
                        prefixIcon: Icon(
                          Icons.lock,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: InkWell(
                        onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => ResetPasswordScreen()));
                        },
                        child: Text('Forgot Password', style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w700,
                            color: Colors.blue
                        ),),
                      ),
                    ),
                    Center(
                      child: SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(Color(0XFF190152)),
                            shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(color: Colors.black, width: 2),
                              ),
                            ),
                            overlayColor: MaterialStateProperty.all(Colors.black12),
                          ),
                          onPressed: () {
                            Navigator.push(
                                context, MaterialPageRoute(builder: (context) => HomeScreen()));
                          },
                          child: Text(
                            'Login Me',
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Colors.white
                            ),
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                      Flexible(child: Divider(color: Colors.grey,)),
                      Text(
                          '   Or signup with   ',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Flexible(child: Divider(color: Colors.grey,)),
                    ],),
                    Center(child: Icon(Icons.facebook, color: Colors.blue, size: 40,)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Not registered yet?? ' ,style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700,
                        ),),
                        InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));
                          },
                          child: Text('Create Account ' ,
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700,
                                color: Colors.blue
                            ),),
                        ),
                      ],
                    ),
                  ] else ...[
                    // Phone Login Fields
                    TextFormField(
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Phone Number',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.deepPurple, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        fillColor: Colors.amber.shade50,
                        filled: true,
                        prefixIcon: Icon(
                          Icons.phone,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                    Center(
                      child: SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(Color(0XFF190152)),
                            shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(color: Colors.black, width: 2),
                              ),
                            ),
                            overlayColor: MaterialStateProperty.all(Colors.black12),
                          ),
                          onPressed: () {
                            Navigator.push(
                                context, MaterialPageRoute(builder: (context) => HomeScreen()));
                          },
                          child: Text(
                            'Send Otp',
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Colors.white
                            ),
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Flexible(child: Divider(color: Colors.grey,)),
                        Text(
                          '   Or signup with   ',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Flexible(child: Divider(color: Colors.grey,)),
                      ],),
                    Center(child: Icon(Icons.facebook, color: Colors.blue, size: 40,)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Not registered yet?? ' ,style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700,
                        ),),
                        InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen()));
                          },
                          child: Text('Create Account ' ,
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700,
                                color: Colors.blue
                            ),),
                        ),
                      ],
                    ),
                  ],
              
              
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
