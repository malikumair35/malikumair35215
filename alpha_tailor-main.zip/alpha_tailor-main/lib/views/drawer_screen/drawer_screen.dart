import 'package:flutter/material.dart';

import '../tailor_detail/tailor_detail.dart';


//
// void main() {
//   runApp(MaterialApp(
//     debugShowCheckedModeBanner: false,
//     home: DrawerScreen(),
//     routes: {
//       '/profile': (context) => ProfileScreen(),
//       '/settings': (context) => SettingsScreen(),
//       '/privacy': (context) => PrivacyPolicyScreen(),
//       '/tailor_points': (context) => TailorPointsScreen(),
//     },
//   ));
// }

// Dummy screens
class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: true,),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            spacing: 17,
            children: [

              Row(
                children: [

                  CircleAvatar(
                    radius: 40,
                  ),
                  SizedBox(width: 15,),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Ahmed janjua'),
                      Text('Tailoring of male and female outfits'),
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber,),
                          Icon(Icons.star, color: Colors.amber,),
                          Icon(Icons.star, color: Colors.amber,),
                          Icon(Icons.star_border_outlined, color: Colors.amber,),
                        ],
                      )

                    ],),
                ],
              ),

              Center(
                child: Container(
                  height: 100,
                  width: 300,
                  decoration: BoxDecoration(
                      color: Colors.blueGrey,
                      borderRadius: BorderRadius.circular(12)
                  ),
                  child: Center(child: Text('Completed: 120 orders\n Inprogress: 18', style: TextStyle(color: Colors.white, fontSize: 18),)),
                ),
              ),

              Text('Available designs', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w700),),
              Flexible(
                child: GridView.builder(
                  itemCount: 4,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 12/7,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10

                  ),
                  itemBuilder: (context, index) {
                    return Container(
                      height: 120, width: 120,
                      decoration: BoxDecoration(
                          color: Colors.deepPurple,
                          border: Border.all(color: Colors.deepOrange),
                          borderRadius: BorderRadius.circular(12)
                      ),
                    );
                  },),
              ),
              Text('Contact Me', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w700),),
              Divider(color: Colors.deepPurple,thickness: 2,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Icon(Icons.phone, size: 30,),
                      Text('Phone Call', style: TextStyle(color: Colors.black, fontSize: 14,),),
                    ],
                  ),
                  Column(
                    children: [
                      Icon(Icons.phone, size: 30,),
                      Text('Whatsapp Call', style: TextStyle(color: Colors.black, fontSize: 14,),),
                    ],
                  ),
                  Column(
                    children: [
                      Icon(Icons.phone, size: 30,),
                      Text('Skype Call', style: TextStyle(color: Colors.black, fontSize: 14,),),
                    ],
                  ),

                ],
              ),
              Divider(color: Colors.deepPurple,thickness: 2,),
              Text('Hire Me', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w700),),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: (){
                      showDialog(context: (context), builder: (context) {
                        return CustomMeasurements();
                      },);
                    },
                    child: Container(
                      height: 40, width: 140,
                      color: Colors.green,
                      child: Center(child: Text('Hire Me', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),)),
                    ),
                  ),
                  Container(
                    height: 40, width: 140,
                    color: Colors.green,
                    child: Center(child: Text('Cancel Order', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),)),
                  ),
                ],
              ),
              SizedBox(height: 40,),

            ],
          ),
        ),
      ),
    );
  }
}


class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Text(
          'Settings Screen',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}



class PrivacyPolicyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Privacy Policy'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          'Privacy Policy content goes here.',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}



class OrdersScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Orders/Booking'),
      ),
      body: Center(
        child: Text(
          'Orders Screen',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
//
//
// class SuitTrackingScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Suit Tracking'),
//       ),
//       body: Center(
//         child: Text(
//           'Suit Tracking Screen',
//           style: TextStyle(fontSize: 20),
//         ),
//       ),
//     );
//   }
// }


class NotificationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
      ),
      body: Center(
        child: Text(
          'Notifications Screen',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}


class HelpSupportScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Help & Support'),
      ),
      body: Center(
        child: Text(
          'Help & Support Screen',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}



class TailorPointsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tailor Points'),
      ),
      body: Center(
        child: Text(
          'Tailor Points Screen',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
// void main() {
//   runApp(MaterialApp(
//     initialRoute: '/',
//     routes: {
//       '/': (context) => HomeScreen(), // Replace with your home screen
//       '/profile': (context) => ProfileScreen(),
//       '/settings': (context) => SettingsScreen(),
//       '/privacy': (context) => PrivacyPolicyScreen(),
//       '/orders': (context) => OrdersScreen(),
//       '/tracking': (context) => SuitTrackingScreen(),
//       '/notifications': (context) => NotificationsScreen(),
//       '/help': (context) => HelpSupportScreen(),
//       '/tailor_points': (context) => TailorPointsScreen(),
//     },
//   ));
// }
