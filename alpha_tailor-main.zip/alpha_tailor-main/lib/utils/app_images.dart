

class AppImages{
  static const tailorIcon = 'assets/images/tailor.png';
  static const bgImage = 'assets/images/bg.webp';
  static const sewMachine = 'assets/images/sewingMachine.png';

  static const resetPassword = 'assets/images/images.png';
  static const updatePassword = 'assets/images/updated.jpg';

  static const resetPassword1 = 'assets/images/pic1.jpg';
  static const resetPassword2 = 'assets/images/pic2.jpg';
  static const resetPassword3 = 'assets/images/pic3.jpg';

  static const image1 = 'assets/images/img1.jpg';
  static const image2 = 'assets/images/img2.jpg';
  static const image3 = 'assets/images/img3.jpg';
  static const image4 = 'assets/images/img4.jpg';
  static const image5 = 'assets/images/img5.jpg';


}
