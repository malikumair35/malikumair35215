package com.example.alpha_tailor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
